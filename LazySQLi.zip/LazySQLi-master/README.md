# LazySQLi
Sqlmap for lazy people

An advanced sql injection tools that work with sqlmap to make it more effective. It has more than 12 tamper scripts pre-commanded to run on single click. 

# How to install
To install it in Kali linux and other linux operating systems please refer to this article - https://www.kalilinux.in/2019/03/advanced-sql-injection-in-easy-stapes.html

To install this tool in termux, copy paste the following commands 

1. git clone https://github.com/cipherhexx/LazySQLi
2. cd LazySQLi
3. chmod +x LazySqli
4. ./LazySqli

there are no requirements needed :) it will install everything so for the first start it will take 2-3 minutes to start but then next time it will run instantly 

